<?php include("header.php");?>

 <div class="content mt-3">
 <div class="animated fadeIn">
     <div class="row">

         <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                     <strong class="card-title">Vahicles</strong>
                 </div>
                 <div class="card-body">
                     <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                         <thead>
                             <tr>
                                 <th>Car Name</th>
                                 <th>Car Number</th>
                                 <th>Car Position</th>
                                 <th>Time Information</th>
                                 <th>Action</th>
                               
                             </tr>
                         </thead>
                         <tbody>
                             <tr>
                                 <td>Taxi</td>
                                 <td>Ac1235</td>
                                 <td>A90</td>
                                 <td>28/2/2024</td>
                               
                                  <td class=" btn-outline-danger text-white fw-bold " > <a href="#" >Delete</a></td>
                                
                             </tr>
                             <tr>
                             <td>motor</td>
                                 <td>Af8393</td>
                                 <td>A91</td>
                                 <td>27/2/2024</td>
                                 <td class=" btn-outline-danger text-white fw-bold " ><a href="#" >Delete</a></td> 
                             </tr>
                             <tr>
                             <td>Proof</td>
                                 <td>AG0184</td>
                                 <td>A92</td>
                                 <td>26/2/2024</td>
                                <td class=" btn-outline-danger text-white fw-bold " ><a href="#" >Delete</a></td> 
                             </tr>
                            
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>


     </div>
 </div><!-- .animated -->
</div>