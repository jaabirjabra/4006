<?php include("header.php");
?>
<div class="col-xs-6 col-sm-10">
                        <div class="card " style="margin-left:20%;">
                            <div class="card-header">
                                <strong>Form Page</strong> 
                            </div>
                            <div class="card-body card-block">
                                <div class="form-group">
                                    <label class=" form-control-label">Car Name</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-addon"><i class="fa fa-user"></i></div> -->
                                        <input class="form-control" name="join">
                                    </div>
                             
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Car Number</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-addon"><i class="fa fa-user"></i></div> -->
                                        <input class="form-control" name="leave">
                                    </div>
                                  
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Car Position</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-addon"><i class="fa fa-user"></i></div> -->
                                        <input class="form-control" name="join">
                                    </div>
                             
                                </div>
                                <div class="form-group">
                                    <label class=" form-control-label">Time Information</label>
                                    <div class="input-group">
                                        <!-- <div class="input-group-addon"><i class="fa fa-user"></i></div> -->
                                        <input type="date" class="form-control" name="leave">
                                    </div>
                                  
                                </div>
                                 
                               
                            </div>
                        </div>
                    </div>
