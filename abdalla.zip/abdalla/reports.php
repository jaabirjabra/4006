<?php include("header.php");?>

 <div class="content mt-3">
 <div class="animated fadeIn">
     <div class="row">

         <div class="col-md-12">
             <div class="card">
                 <div class="card-header">
                     <strong class="card-title">Report Cars</strong>
                 </div>
                 <div class="card-body">
                     <table id="bootstrap-data-table-export" class="table table-striped table-bordered">
                         <thead>
                             <tr>
                                 <th>Car Name</th>
                                 <th>Car Number</th>
                                 <th>Street</th>
                                
                               
                             </tr>
                         </thead>
                         <tbody>
                             <tr>
                                 <td>Prado</td>
                                 <td>Aj1212</td>
                                 <td>Howlwadaag</td>
                               
                             </tr>
                             <tr>
                                 <td>track</td>
                                 <td>Ad6713</td>
                                 <td>Sanca</td>
                               
                             </tr>
                            
                         </tbody>
                     </table>
                 </div>
             </div>
         </div>


     </div>
 </div><!-- .animated -->
</div>